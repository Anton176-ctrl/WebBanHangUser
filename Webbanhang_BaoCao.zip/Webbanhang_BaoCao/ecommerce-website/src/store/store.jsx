import { configureStore } from '@reduxjs/toolkit';
import cartReducer from '../slices/CartSlice'; // thích đặt tên j thì đặt

const store = configureStore({
  reducer: {
    cart: cartReducer, // đặt xong thì đặt nó ở đây
  },
});

export default store;

