import React from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import Home from "./components/Home";
import ProductDetail from "./components/ProductDetail";
import Cart from "./components/Cart";
import CheckOut from "./components/CheckOut";
import Header from "./components/Header";



function App() {
  return (
    <Router>
   <div>
    <Header />
      <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/cart/" element={<Cart />} />
          <Route path="/checkout" element={<CheckOut />} />
      </Routes>
   </div>
   </Router>
  );
}

export default App;
