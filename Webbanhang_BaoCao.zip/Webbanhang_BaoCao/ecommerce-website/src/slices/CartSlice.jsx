import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";



// Tạo async action để lưu giỏ hàng lên server
// Gửi giỏ hàng lên server
export const saveCartToServer = createAsyncThunk(
    'cart/saveCartToServer',
    async (cartItems, {getState}) => {
        const userId = getState().user.id;
        const response = await axios.post(`/https://fakestoreapi.com/cart`, {userId, items: cartItems})
        return response.data;
    }
);  


// Lấy giỏ hàng từ server khi tải trang


// dispatch(action): Khi bạn gọi dispatch,
// bạn sẽ gửi action này đến Redux store. Store sẽ nhận action và chuyển nó đến reducer tương ứng để xử lý.


// Bắt buộc phải đặt là intial chứ ko là cút đấy vì trong Redux nó hoạt động như vậy
// Cái form của nó là như vậy nên đừng thay đổi j cả
// const initialState = {
//     items: [], // Mảng rỗng ban đầu
//   };

const cartSlice = createSlice({
    name: 'cart',
    initialState: {
        items: [],
        status: 'idle',
    } ,
    reducers:{
        addItemToCart: (state, action) => {
            const item = action.payload; //Dữ liệu của sản phẩm được truyền vào khi gọi action. payload chứa thông tin chi tiết của sản phẩm như id, title, price, image, v.v.
            const spDaTonTai = state.items.find((i)=> i.id === item.id);    //là mảng các sản phẩm hiện tại trong giỏ hàng.

            if(spDaTonTai){
                spDaTonTai.quantity += 1
            } else {
                state.items.push({...item,  quantity: 1});
            }
        },

        removeItemFromCart: (state, action) => {
            const id = action.payload;
            state.items = state.items.filter((i)=> i.id !== id);
        },

        clearCart: (state) => {
            state.items = [];
        },

    },

    extraReducers: (builder) => {
        builder
        .addCase(saveCartToServer.pending, (state) => {
            state.status = 'loading';
        })
        .addCase(saveCartToServer.fulfilled, (state, action) => {
            state.status = 'idle';
            // Xử lý kết quả trả về từ API : action
        })
        .addCase(saveCartToServer.rejected, (state) => {
            state.status = 'failed';
        })

    }
});

export const { addItemToCart, removeItemFromCart, clearCart } = cartSlice.actions;
export default cartSlice.reducer;


// export const { ... } = cartSlice.actions;: Xuất các action creators để bạn có thể dispatch chúng từ component,
// giúp thực hiện các hành động như thêm, xóa, hoặc xóa toàn bộ giỏ hàng.


// export default cartSlice.reducer;: Xuất reducer của cartSlice,
// đây là hàm xử lý thay đổi trạng thái của giỏ hàng và cần được kết hợp vào Redux store để quản lý trạng thái toàn cục của ứng dụng.