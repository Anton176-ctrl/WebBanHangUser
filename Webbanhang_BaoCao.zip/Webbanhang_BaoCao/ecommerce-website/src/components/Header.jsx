// components/Header.js
import React from 'react';
import { Link } from 'react-router-dom';
import '../css/Header.css'; // Tạo file CSS cho Header

function Header() {
  return (
    <header className="header">
      <nav className="navbar">
        <h1 className="logo">MyShop</h1>
        <ul className="nav-links">
          <li><Link to="/">Trang chủ</Link></li>
          <li><Link to="/cart">Giỏ hàng</Link></li>
          <li><Link to="/checkout">Thanh toán</Link></li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
