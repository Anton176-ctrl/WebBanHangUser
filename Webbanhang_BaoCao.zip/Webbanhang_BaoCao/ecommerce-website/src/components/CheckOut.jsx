import React from 'react'

function CheckOut() {
  return (
    <div>
      Checkout
    </div>
  )
}

export default CheckOut
