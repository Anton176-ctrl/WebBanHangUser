import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {Link} from "react-router-dom";
import '../css/Home.css'
function Home() {

    const [products, setProducts] = useState([]);

    useEffect(()=>{
        axios.get("https://fakestoreapi.com/products?limit=12")
        .then((res)=>{
            setProducts(res.data)
            console.log(res.data);
            
        })
    }, [])


  return (
    <div>
        <h1>Sản phẩm nổi bật</h1>
        <div className='product-list'>
      {products.map((i)=>{
        return  <div key={i.id} className='product'>
         <Link to={`/product/${i.id}`}>
        <img src={i.image} alt={i.title} />
        <h2>Tiêu đề: {i.title}</h2>
        <p>Mô tả: {i.description}</p>
        <span>Giá: {i.price} $</span>
        </Link>
        </div>
        
   
      })}
    </div>
    </div>
  )
}

export default Home
