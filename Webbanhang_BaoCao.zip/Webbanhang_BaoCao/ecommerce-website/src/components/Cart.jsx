import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { removeItemFromCart, clearCart, saveCartToServer } from '../slices/CartSlice';
import '../css/Cart.css';
import axios from 'axios';

function Cart() {

  const cartItems = useSelector((state)=> 
    state.cart.items
  );
  const dispatch = useDispatch();


  const handleRemoveItem = (id) => {
      dispatch(removeItemFromCart(id));
      dispatch(saveCartToServer(cartItems))
  };

  const handleClearCart = () => {
    dispatch(clearCart());
    dispatch(saveCartToServer([]));

  };


// Lấy giỏ hàng từ server khi trang được tải
  // useEffect(()=>{
  //   const fetchCart = async () => {
  //     try {
  //     // Lấy thông tin người dùng từ API
  //     const userRes = await axios.get(`/https://fakestoreapi.com/users`)
  //     const userId = userRes.data.id;

  //     // Lấy giỏ hàng bằng userId
  //     const cartResponse = axios.get(`/https://fakestoreapi.com/cart/${userId}`);
  //     const cartData = cartResponse.data.items

  //     // Dispatch action để lưu giỏ hàng
  //     dispatch(saveCartToServer(cartData))
  //     } catch (error) {
  //       console.log(error);
        
  //     }
      
  // };

  // fetchCart();

  // },[dispatch])

  useEffect(() => {
    dispatch(saveCartToServer(cartItems));
  }, [cartItems, dispatch]);

  return (
    <div className="cart-container">
    <h2>Giỏ hàng</h2>
    {cartItems.length === 0 ? (
      <p className="cart-empty">Giỏ hàng trống</p>
    ) : (
      <div>
        {cartItems.map((i) => (
          <div key={i.id} className="cart-item">
            <img src={i.image} alt={i.title} />
            <div className="cart-item-info">
              <h3>Tiêu đề: {i.title}</h3>
              <p>Giá: {i.price} $</p>
              <p>Số lượng: {i.quantity}</p>
            </div>
            <div className="cart-item-actions">
              <button onClick={() => handleRemoveItem(i.id)}>Xóa</button>
            </div>
          </div>
        ))}
        <button className="cart-clear-btn" onClick={handleClearCart}>
          Xóa tất cả
        </button>
      </div>
    )}
  </div>
  
  )
}

export default Cart


// Khi nên thêm API giỏ hàng:

// Nếu bạn quyết định sử dụng API giỏ hàng (có thể là một phần của backend), bạn cần phải:

//     Thêm API call để lưu và lấy giỏ hàng từ backend:
//         Gọi API để lưu trữ giỏ hàng mỗi khi có sự thay đổi.
//         Khi người dùng tải lại trang hoặc đăng nhập, gọi API để lấy lại giỏ hàng từ server.


// Tóm lại:

//     Nếu bạn đang quản lý giỏ hàng cục bộ bằng Redux mà không cần lưu trữ dữ liệu trên server, không cần thêm API giỏ hàng.
//     Nếu bạn muốn giỏ hàng được đồng bộ với backend (đặc biệt trong trường hợp có nhiều người dùng), bạn sẽ cần thêm API giỏ hàng vào code.