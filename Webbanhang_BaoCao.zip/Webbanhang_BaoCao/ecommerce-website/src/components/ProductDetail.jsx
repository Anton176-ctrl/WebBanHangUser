import React, {useState, useEffect} from 'react';
import { Navigate, useParams } from 'react-router-dom';
import axios from 'axios';
import '../css/ProductDetail.css';
import { useDispatch } from 'react-redux';
import { addItemToCart } from '../slices/CartSlice';
import { useNavigate } from 'react-router-dom';

function ProductDetail() {

  const navigate = useNavigate();


  const { id } = useParams();
  const [products, setProducts] = useState({});
  // const [cart, setCart] = useState([]) 

  const dispatch = useDispatch();

  const handleAddToCart = () =>{
    console.log(products);
    
    dispatch(addItemToCart(products));
    navigate('/cart'); 
  }

  
  // useEffect(()=>{
  //   axios.get(`https://fakestoreapi.com/carts/${id}`)
  //   .then((res)=>{
  //     setCart(res.data)
  //   })
  // }, [id])

  useEffect(()=>{
    axios.get(`https://fakestoreapi.com/products/${id}`)
    .then((res)=>{
      setProducts(res.data)
    })
  }, [id])


  return (
    <div className='product-detail'>
      <div className='title'>
      <h1>{products.title}</h1>
      <img src={products.image} alt={products.title} />
      </div>
      <div className='des'>
      <p>Mô tả: {products.description}</p>
      <p>Giá: {products.price} $</p>
      <button onClick={handleAddToCart}>Thêm sản phẩm vào giỏ hàng</button>
      </div>
    </div>
  )
}

export default ProductDetail
